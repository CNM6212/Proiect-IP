﻿namespace DataAccess
{
    public interface IEntity
    {
    }
}
